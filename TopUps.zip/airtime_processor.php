<?php
	require_once("app/functions.php");
	require_once("app/database.php");
	//header("Content-Type: application/json");
	$phone_number = Database::escaped_string($_POST['phoneNumber']);
	$network = Database::escaped_string($_POST['network']);
	$amount = Database::escaped_string($_POST['amount']);
	$link = "https://mobilenig.net/api/airtime.php/?username=Topupsng&password=View@131&network=$network&phoneNumber=$phone_number&amount=$amount";
	$answer = file_get_contents($link);
	echo json_decode($answer);
	// function get_data($url) {
	// 	$ch = curl_init();
	// 	$timeout = 30;
	// 	curl_setopt($ch, CURLOPT_URL, $url);
	// 	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	// 	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
	// 	$data = curl_exec($ch);
	// 	curl_close($ch);
	// 	return $data;
	// }
	// $returned_content = get_data($link);
	//echo json_encode($returned_content);
