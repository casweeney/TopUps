            <div class="container">
                <h3 class="text-white text-center">Welcome Casweeney Ojukwu</h3>
                <div class="row text-center">
                    <div class="col-md-3">                        
                        
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h4>NGN 0.00</h4>
                                <div class="underliner"></div>
                                <h5>Account Balance</h5>
                            </div>
                            <div class="card-footer">
                                <a href="access_granted.php?fund_account" class="btn btn-primary">Fund Account</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        
                    </div>
                </div>

                <div class="row text-center">
                    <div class="col-md-6">                        
                        <div class="card">
                            <div class="card-body">
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row text-center">
                    <div class="col-md-12">                        
                        <div class="card">
                            <div class="card-body">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>