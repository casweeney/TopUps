            <div class="container">
                <div class="row text-center">
                    <div class="col-md-4">                        
                        
                    </div>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                
                            </div>
                        </div>
                        <br>
                        <div class="card">
                            <div class="card-body">
                                
                            </div>
                        </div>
                        <br>
                        <div class="card">
                            <div class="card-body">
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        
                    </div>
                </div>
            </div>