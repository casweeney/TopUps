            <div class="container">
                <h3 class="text-white text-center">Fund Account</h3>
                <div class="row">
                    <div class="col-md-6">                        
                        <div class="card">
                            <div class="card-body">
                                <h4 class="text-center">Online Payment - Instant Funding</h4>
                                <br>
                                <form action="/action_page.php">
                                  <div class="form-group">
                                    <input type="number" placeholder="Amount" class="form-control" id="amount">
                                  </div>
                                  <center><button type="submit" class="btn btn-info" style="padding-right: 20%; padding-left: 20%; border-radius: 2px;">Proceed</button></center>
                                </form>
                                <br>   
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="text-center">Bank Transfer - Cash Deposit</h4>
                                <p class="text-info">
                                    Pay via cash deposit, internet banking, mobile banking transfer to any of the accounts below; <br><br>

                                    Account Name: Zizocon Technologies Ltd. <br>
                                    Account No: 2029998090<br>
                                    Bank: First Bank
                                </p>
                                <br>
                                <form action="/action_page.php">
                                  <div class="form-group">
                                    <input type="number" placeholder="Amount" class="form-control" id="amount">
                                  </div>
                                  <div class="form-group">
                                    <textarea class="form-control" placeholder="Please state sender account name and bank."></textarea>
                                  </div>
                                  <center><button type="submit" class="btn btn-info" style="padding-right: 20%; padding-left: 20%; border-radius: 2px;">Send Payment Notification</button></center>
                                </form>
                                <br>   
                            </div>
                        </div>
                        <br>
                    </div>
                </div>
            </div>