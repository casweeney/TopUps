            <div class="container">
                <h3 class="text-white text-center">Mobile Data Topup</h3>
                <div class="row text-center">
                    <div class="col-md-3">                        
                        
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <form action="/action_page.php">
                                  <div class="form-group">
                                    <input type="number" placeholder="Phone number" class="form-control" id="phone">
                                  </div>
                                  <div class="form-group">
                                    <select class="form-control">
                                        <option selected>Select Mobile Network</option>
                                        <option>MTN</option>
                                        <option>GLO</option>
                                        <option>Airtel</option>
                                        <option>9mobile</option>
                                    </select>
                                  </div>
                                  <div class="form-group">
                                    <select class="form-control">
                                        <option selected>Select Price</option>
                                        <option value='60000'>1 GB - #600</option>
                                        <option value='110000'>2 GB - #1100</option>
                                        <option value='160000'>3 GB - #1600</option>
                                        <option value='220000'>4 GB - #2200</option>
                                        <option value='280000'>5 GB - #2800</option>
                                    </select>
                                  </div>
                                  <center><button type="submit" class="btn btn-info" style="padding-right: 20%; padding-left: 20%; border-radius: 2px;">Send Data</button></center>
                                </form>
                                <br>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        
                    </div>
                </div>
            </div>